/**
 * saasWebhook.js — The Accountant's Phone
 * Route: POST /api/webhook
 *
 * Microsoft calls this endpoint every time anything changes with any subscription.
 * Think of it like an automated phone call from Microsoft's billing department.
 * They ring, tell us what happened, and we have to say "got it" within 10 seconds.
 *
 * Events we handle:
 *   Subscribed      — A new subscription was created (backup to the activation page)
 *   Unsubscribed    — Customer cancelled. We mark them as Unsubscribed.
 *   Suspended       — Payment failed. We mark them as Suspended (no access).
 *   Reinstated      — Payment fixed. We mark them as Active again.
 *   ChangePlan      — Customer upgraded or downgraded. We update their plan.
 *   ChangeQuantity  — Customer changed seat count. We update quantity.
 *   Renew           — Auto-renewal happened. We just log it.
 *
 * The pattern: respond to Microsoft IMMEDIATELY (under 10 seconds),
 * then do the slow database work in the background.
 *
 * This URL must be registered in Partner Center as the "Webhook URL".
 * Microsoft sends a signed JWT in the Authorization header — we validate it.
 */

// Azure Functions v4 SDK.
const { app } = require("@azure/functions");

// jwt library — used here to decode/validate Microsoft's webhook signature.
const jwt = require("jsonwebtoken");

// Our storage helpers — we'll use these to update subscription records.
const {
  upsertSubscription,          // Create or update a subscription
  updateSubscriptionStatus,    // Just change the status field
  getSubscriptionById          // Look up a subscription by ID alone (no tenantId needed)
} = require("../shared/tableStorage");

// Our Fulfillment API client — used to:
// 1. Get full subscription details when a Subscribed event arrives
// 2. Acknowledge operations (tell Microsoft "we received and processed your event")
const { acknowledgeOperation, getSubscription: getMarketplaceSubscription } = require("../shared/fulfillmentClient");
// Note: 'getSubscription' is renamed to 'getMarketplaceSubscription' to avoid confusion
// with our own storage helper's getSubscription function.

// The expected issuer for Microsoft's webhook JWT tokens.
// Any token claiming to come from somewhere else is rejected.
const MARKETPLACE_ISSUER = "https://marketplaceapi.microsoft.com";

/**
 * validateWebhookAuth — Validates the Microsoft-signed JWT in the Authorization header.
 *
 * Microsoft signs every webhook request with a JWT to prove it's really from them.
 * Without validation, anyone could POST fake events to our webhook URL and cancel
 * subscriptions maliciously (e.g. someone sends a fake "Unsubscribed" event).
 *
 * Current implementation: structural validation (check issuer claim is correct).
 * TODO for production: add full JWKS signature verification using Microsoft's
 * published public key endpoint for cryptographic proof.
 *
 * @param {Request} request - The incoming Azure Functions request object
 * @param {object}  context - The Azure Functions context (for logging)
 * @returns {boolean}       - true if the request looks legitimate, false if not
 */
function validateWebhookAuth(request, context) {
  // Read the Authorization header. Microsoft sends: "Bearer eyJ..."
  const authHeader = request.headers.get("authorization") || "";

  // If there's no Authorization header at all, reject immediately.
  // Legitimate Microsoft calls always include this header.
  if (!authHeader.startsWith("Bearer ")) {
    context.log.warn("Webhook: missing or malformed Authorization header");
    return false;
  }

  // Strip the "Bearer " prefix (7 characters) to get just the JWT token string.
  const token = authHeader.slice(7);

  try {
    // jwt.decode() reads the token WITHOUT checking the signature.
    // This is intentional here — we check the claims first.
    // In production, replace this with jwt.verify() against Microsoft's JWKS endpoint
    // to cryptographically prove the signature is from Microsoft's private key.
    const decoded = jwt.decode(token);

    // If decode() returned null, the token is malformed (not a valid JWT structure).
    if (!decoded) {
      context.log.warn("Webhook: could not decode token");
      return false;
    }

    // Check the issuer claim ('iss'). This must match Microsoft's Marketplace API.
    // If it doesn't match, the token came from somewhere unexpected.
    if (decoded.iss !== MARKETPLACE_ISSUER) {
      context.log.warn("Webhook: unexpected token issuer:", decoded.iss);
      return false;
    }

    // Log useful details for debugging — visible in Azure Portal logs.
    // appid = Microsoft's app ID for the Marketplace service
    // tid = the tenant ID the event came from
    context.log(`Webhook auth: publisher=${decoded.appid}, tenant=${decoded.tid}`);
    return true; // Token looks legitimate

  } catch (e) {
    // jwt.decode() threw an unexpected error — token is corrupted or malformed.
    context.log.error("Webhook: auth token decode failed:", e.message);
    return false;
  }
}

// Register the HTTP-triggered Azure Function.
app.http("saasWebhook", {
  methods: ["POST"],     // Microsoft only POSTs to webhooks — no GET needed
  authLevel: "anonymous", // We do our own auth via validateWebhookAuth()
  route: "webhook",      // URL: /api/webhook

  handler: async (request, context) => {

    // ── SECURITY CHECK ────────────────────────────────────────────────────
    // Validate the JWT before doing ANYTHING else.
    // If this fails, we reject with 401 Unauthorized immediately.
    if (!validateWebhookAuth(request, context)) {
      return { status: 401, body: "Unauthorized" };
    }

    // ── PARSE THE REQUEST BODY ────────────────────────────────────────────
    let payload;
    try {
      // Read and parse the JSON body Microsoft sent us.
      payload = await request.json();
    } catch {
      // If the body isn't valid JSON, return 400 Bad Request.
      context.log.error("Webhook: invalid JSON body");
      return { status: 400, body: "Invalid JSON" };
    }

    // Destructure the fields we care about from the payload.
    // The { id: operationId } syntax renames 'id' to 'operationId' to be descriptive.
    const {
      id: operationId,     // Unique ID for this specific operation — used when acknowledging
      subscriptionId,      // The subscription this event is about
      publisherId,         // Our publisher ID (for verification)
      offerId,             // Our offer ID
      planId,              // The plan (present for ChangePlan events)
      quantity,            // The quantity (present for ChangeQuantity events)
      action,              // What happened: "Subscribed", "Unsubscribed", "Suspended", etc.
    } = payload;

    // Log that we received the event. Visible in Azure Portal → Function App → Log stream.
    context.log(`Webhook received: ${action} for subscription ${subscriptionId}, operation ${operationId}`);

    // ── RESPOND IMMEDIATELY, WORK IN BACKGROUND ───────────────────────────
    // Microsoft requires a response within 10 seconds.
    // Database operations can take 1-3 seconds. If we have multiple operations,
    // we could easily exceed 10 seconds if we wait for them.
    // Solution: define the slow work as a function, START it running, but
    // immediately return 200 to Microsoft. The function continues in the background.
    //
    // This is called "fire and forget" — we start the async work and don't await it.

    const asyncWork = async () => {
      try {
        // Handle each event type differently.
        switch (action) {

          case "Subscribed": {
            // A new subscription was purchased (this is a backup to the activation page).
            // Get the full subscription details from Microsoft (webhook payload is minimal).
            const sub = await getMarketplaceSubscription(subscriptionId);

            // Save the full subscription to our Table Storage.
            // ?. is "optional chaining" — safely reads a nested property without crashing
            // if the parent object is undefined or null.
            await upsertSubscription({
              subscriptionId,
              tenantId: sub.beneficiary?.tenantId || sub.purchaser?.tenantId || "unknown",
              purchaserEmail: sub.purchaser?.emailId || "",
              beneficiaryEmail: sub.beneficiary?.emailId || "",
              planId: sub.planId || planId,       // Prefer the full object's planId
              quantity: sub.quantity || quantity || 1,
              offerId: sub.offerId || offerId,
              publisherId,
              status: "Active",
              saasSubscriptionStatus: "Subscribed",
              activatedAt: new Date().toISOString(),
              autoRenew: true
            });
            break; // Exit the switch statement after this case
          }

          case "Unsubscribed": {
            // Customer cancelled. Find their subscription and mark it Unsubscribed.
            // We use getSubscriptionById() because the webhook only gives us subscriptionId,
            // not tenantId. (This was the critical bug fixed in the audit — the old code
            // used getSubscription("unknown", id) which always failed silently.)
            const existing = await getSubscriptionById(subscriptionId);
            const tenantId = existing?.tenantId || "unknown";
            await updateSubscriptionStatus(tenantId, subscriptionId, "Unsubscribed");
            // From now on, licenseCheck.js will find no Active subscription for this tenant.
            break;
          }

          case "Suspended": {
            // Payment failed — Microsoft suspends the subscription.
            // We mark it Suspended so the add-in shows a "payment failed" message.
            const existing = await getSubscriptionById(subscriptionId);
            const tenantId = existing?.tenantId || "unknown";
            await updateSubscriptionStatus(tenantId, subscriptionId, "Suspended");
            break;
          }

          case "Reinstated": {
            // Customer fixed their payment — Microsoft reinstates the subscription.
            // Mark it Active again so users regain access.
            const existing = await getSubscriptionById(subscriptionId);
            const tenantId = existing?.tenantId || "unknown";
            await updateSubscriptionStatus(tenantId, subscriptionId, "Active");
            break;
          }

          case "ChangePlan": {
            // Customer upgraded or downgraded their plan.
            // Update the planId in our record. Status stays Active.
            const existing = await getSubscriptionById(subscriptionId);
            const tenantId = existing?.tenantId || "unknown";
            await upsertSubscription({
              subscriptionId,
              tenantId,
              planId,            // The new plan ID sent in the webhook payload
              quantity: quantity || 1,
              status: "Active",
              updatedAt: new Date().toISOString()
            });
            break;
          }

          case "ChangeQuantity": {
            // Customer changed their seat count.
            // Update the quantity field only — everything else stays the same.
            const existing = await getSubscriptionById(subscriptionId);
            const tenantId = existing?.tenantId || "unknown";
            await upsertSubscription({
              subscriptionId,
              tenantId,
              quantity, // The new quantity sent in the webhook payload
              updatedAt: new Date().toISOString()
            });
            break;
          }

          case "Renew": {
            // Auto-renewal was processed. The subscription continues as-is.
            // No status change needed — we just log it for the record.
            context.log(`Subscription ${subscriptionId} renewed.`);
            break;
          }

          default:
            // An action we don't recognise. Log a warning but don't crash —
            // Microsoft may add new event types in future API versions.
            context.log.warn(`Unhandled webhook action: ${action}`);
        }

        // ── ACKNOWLEDGE THE OPERATION ─────────────────────────────────────
        // After processing the event, we must tell Microsoft we handled it.
        // If we don't acknowledge, Microsoft considers it failed and will retry.
        // We check both IDs exist because some edge-case payloads might be missing them.
        if (operationId && subscriptionId) {
          await acknowledgeOperation(subscriptionId, operationId, "Success");
          context.log(`Acknowledged operation ${operationId}`);
        }

      } catch (err) {
        // Something went wrong in our processing.
        context.log.error(`Webhook async processing failed for action ${action}:`, err);

        // Try to tell Microsoft we failed, so it can retry.
        // This is wrapped in its own try/catch because acknowledgeOperation
        // itself might fail if the network is down.
        try {
          if (operationId && subscriptionId) {
            await acknowledgeOperation(subscriptionId, operationId, "Failure");
          }
        } catch (ackErr) {
          context.log.error("Failed to send failure acknowledgement:", ackErr);
        }
      }
    };

    // START the async work running — but do NOT await it.
    // This means the code continues to the return statement immediately.
    asyncWork(); // Fire and forget ← the background work is now running independently

    // Return 200 immediately to Microsoft — within milliseconds of receiving the request.
    // Microsoft records this as "webhook received successfully".
    // The actual database work is still running in the background.
    return {
      status: 200,
      body: JSON.stringify({ received: true, operationId }),
      headers: { "Content-Type": "application/json" }
    };
  }
});
