/**
 * activate.js — The Front Desk / Activation Landing Page
 * Route: GET /api/activate
 *
 * This is what the customer sees after buying the add-in on AppSource.
 * Microsoft redirects them here with a short-lived "marketplace token" in the URL.
 *
 * Timeline a customer experiences:
 * 1. Customer clicks "Get it now" on AppSource
 * 2. Customer completes the Microsoft purchase flow
 * 3. Microsoft immediately redirects them to: https://our-functions.azurewebsites.net/api/activate?token=XXXX
 * 4. THIS FUNCTION runs, validates the purchase, stores it, and returns a success HTML page
 * 5. Customer sees a "You're all set!" page in their browser
 * 6. Customer opens Outlook, launches the add-in — it's now licensed
 *
 * IMPORTANT: The marketplace token expires in ~10 minutes.
 * We must call resolveSubscription() and activateSubscription() before it expires.
 * If we miss the window, the customer must contact support to manually activate.
 *
 * This URL must be registered in Partner Center as the "Landing page URL".
 */

// Azure Functions v4 SDK — registers our HTTP function with the runtime.
const { app } = require("@azure/functions");

// Import our Fulfillment API client to talk to Microsoft's billing system.
const { resolveSubscription, activateSubscription } = require("../shared/fulfillmentClient");

// Import our storage helper to save the subscription record.
const { upsertSubscription } = require("../shared/tableStorage");

/**
 * successPage — Returns a styled HTML page shown after successful activation.
 * Uses inline CSS so no external files are needed — this function serves everything itself.
 *
 * @param {string} planId - The plan name to display (e.g. "pro")
 * @param {string} email  - The customer's email address to display
 * @returns {string}      - A complete HTML document as a string
 */
function successPage(planId, email) {
  // Template literal — a multi-line string using backticks.
  // ${escapeHtml(planId)} — we always escape user-supplied data before inserting
  // it into HTML to prevent XSS (Cross-Site Scripting) attacks.
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mail Merge — Activated</title>
  <style>
    /* Reset default browser margins and padding */
    * { box-sizing: border-box; margin: 0; padding: 0; }
    /* Center the card vertically and horizontally on the screen */
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #F3F2FB; /* light lavender — matches the add-in's background colour */
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh; /* fill the full browser window height */
      padding: 24px;
    }
    .card {
      background: #fff;
      border-radius: 20px;
      padding: 48px 40px;
      max-width: 480px;
      width: 100%;
      text-align: center;
      box-shadow: 0 8px 40px rgba(108,98,212,0.12); /* subtle purple shadow */
    }
    .icon { font-size: 56px; margin-bottom: 20px; }
    h1 { font-size: 26px; color: #1C1C1E; margin-bottom: 12px; font-weight: 700; }
    p { color: #6B6B6B; font-size: 15px; line-height: 1.6; margin-bottom: 8px; }
    /* Purple pill badge showing the plan name */
    .plan-badge {
      display: inline-block;
      background: linear-gradient(135deg, #6C62D4, #534AB7);
      color: #fff;
      border-radius: 99px;
      padding: 4px 18px;
      font-size: 13px;
      font-weight: 600;
      margin: 16px 0 24px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .hint { font-size: 13px; color: #9999AA; margin-top: 24px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">✅</div>
    <h1>You're all set!</h1>
    <p>Your Mail Merge subscription is now active.</p>
    <div class="plan-badge">${escapeHtml(planId)}</div>
    <p>Open Outlook and launch the Mail Merge add-in from the ribbon to get started.</p>
    <p class="hint">Activated for ${escapeHtml(email)}</p>
  </div>
</body>
</html>`;
}

/**
 * errorPage — Returns a styled HTML error page if activation fails.
 *
 * @param {string} message - The error message to display to the user
 * @returns {string}       - A complete HTML document as a string
 */
function errorPage(message) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mail Merge — Activation Error</title>
  <style>
    body { font-family: -apple-system, sans-serif; background: #F3F2FB; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
    .card { background: #fff; border-radius: 20px; padding: 48px 40px; max-width: 480px; text-align: center; box-shadow: 0 8px 40px rgba(0,0,0,0.08); }
    h1 { color: #EB5757; margin-bottom: 12px; } /* red heading for errors */
    p { color: #6B6B6B; }
  </style>
</head>
<body>
  <div class="card">
    <div style="font-size:48px;margin-bottom:16px">⚠️</div>
    <h1>Activation failed</h1>
    <p>${escapeHtml(message)}</p>
    <p style="margin-top:16px;font-size:13px;color:#999">Please contact support at leighton@prometheanit.com</p>
  </div>
</body>
</html>`;
}

/**
 * escapeHtml — Converts special characters to safe HTML entities.
 *
 * WHY THIS MATTERS (XSS Prevention):
 * If an attacker somehow injected a plan name like: <script>alert('hacked')</script>
 * and we put that directly into HTML, the browser would execute the script.
 * escapeHtml turns '<' into '&lt;' and '>' into '&gt;', making it display as
 * literal text instead of executing as code.
 *
 * @param {string} str - Any string that might contain unsafe characters
 * @returns {string}   - The string with special chars replaced by HTML entities
 */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")   // & must go first (otherwise we'd double-escape)
    .replace(/</g, "&lt;")    // < would start an HTML tag
    .replace(/>/g, "&gt;")    // > would close an HTML tag
    .replace(/"/g, "&quot;"); // " inside attributes would break out of the attribute
}

// Register the HTTP-triggered Azure Function.
app.http("activate", {
  methods: ["GET"],      // Only GET requests — this is a page the browser navigates to
  authLevel: "anonymous", // No function key required — it's a public landing page
  route: "activate",     // URL: /api/activate

  handler: async (request, context) => {
    // Set up HTML response headers. This is a web page, not JSON.
    const htmlHeaders = { "Content-Type": "text/html; charset=utf-8" };

    // Read the marketplace token from the URL query string.
    // Microsoft appends it like: /api/activate?token=eyJ...
    const marketplaceToken = request.query.get("token");

    // If there's no token, someone navigated to this page directly (not via AppSource).
    // Return an error — we have nothing to activate.
    if (!marketplaceToken) {
      return {
        status: 400,
        headers: htmlHeaders,
        body: errorPage("No activation token provided. Please purchase through Microsoft AppSource.")
      };
    }

    try {
      // ── STEP 1: RESOLVE THE TOKEN ─────────────────────────────────────────
      // Exchange the short-lived marketplace token for full subscription details.
      // This is like exchanging a voucher for the actual product information.
      context.log("Resolving marketplace token...");
      const resolved = await resolveSubscription(marketplaceToken);
      context.log("Resolved subscription:", resolved.id, resolved.planId);

      // Destructure the fields we need from the resolved subscription object.
      // The { id: subscriptionId } syntax renames 'id' to 'subscriptionId' for clarity.
      const {
        id: subscriptionId,  // Microsoft's UUID for this subscription
        planId,              // Which plan was purchased (e.g. "pro")
        quantity,            // Number of seats (usually 1 for per-org plans)
        offerId,             // The offer this subscription is for (our product ID)
        publisherId,         // Our publisher ID in Partner Center
        purchaser,           // The person who clicked "buy" — their email and tenantId
        beneficiary          // The person/org who will USE the product — may differ from purchaser
      } = resolved;

      // Get the tenant ID. Prefer beneficiary (the org using it) over purchaser (the buyer).
      // In enterprise scenarios these can be different — e.g. IT department buys for all users.
      const tenantId = beneficiary?.tenantId || purchaser?.tenantId;

      // The ?. is "optional chaining" — safely reads a property even if the object is null.
      // If beneficiary is null, beneficiary?.emailId returns undefined instead of throwing.
      const email = beneficiary?.emailId || purchaser?.emailId || "unknown";

      // If we couldn't determine the tenant, something is seriously wrong. Abort.
      if (!tenantId) {
        throw new Error("Could not determine tenant ID from marketplace token.");
      }

      // ── STEP 2: ACTIVATE THE SUBSCRIPTION ────────────────────────────────
      // Tell Microsoft "we've seen the purchase and we're accepting it".
      // Without this call, Microsoft holds the subscription in a "PendingFulfillmentStart"
      // state and may auto-cancel it if we don't respond within a few days.
      await activateSubscription(subscriptionId, planId, quantity || 1);
      context.log("Subscription activated:", subscriptionId);

      // ── STEP 3: STORE IN TABLE STORAGE ───────────────────────────────────
      // Save the subscription to OUR database so licenseCheck.js can find it later.
      // This is the record that determines whether users are licensed going forward.
      await upsertSubscription({
        subscriptionId,               // Microsoft's UUID — this is our RowKey
        tenantId,                     // Org's tenant ID — this is our PartitionKey
        purchaserEmail: purchaser?.emailId || email,   // Who bought it
        beneficiaryEmail: beneficiary?.emailId || email, // Who uses it
        planId,                       // "pro", "enterprise", etc.
        quantity: quantity || 1,      // Number of seats
        offerId,                      // Our product's offer ID
        publisherId,                  // Our publisher ID
        status: "Active",             // Start as Active — webhook will update if anything changes
        saasSubscriptionStatus: "Subscribed", // Microsoft's status string
        activatedAt: new Date().toISOString(), // When we activated it
        autoRenew: true               // Subscriptions auto-renew by default
      });
      context.log("Subscription stored in Table Storage.");

      // ── STEP 4: RETURN SUCCESS PAGE ───────────────────────────────────────
      // Show the customer a nice confirmation page in their browser.
      return {
        status: 200,
        headers: htmlHeaders,
        body: successPage(planId, email) // Both values are escaped inside successPage()
      };

    } catch (err) {
      // Something went wrong — log the full error for debugging in Azure Portal.
      context.log.error("Activation error:", err);

      // Show the customer an error page instead of a raw error message.
      // We don't show err.message to the user (could contain sensitive info).
      return {
        status: 500,
        headers: htmlHeaders,
        body: errorPage("An error occurred during activation. Please try again or contact support.")
      };
    }
  }
});
