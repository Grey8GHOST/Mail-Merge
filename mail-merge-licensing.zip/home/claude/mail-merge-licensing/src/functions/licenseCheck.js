/**
 * licenseCheck.js — The Bouncer Function
 * Route: GET /api/license
 *
 * This is the most frequently called function in the entire system.
 * The Outlook add-in calls it on startup to answer one question:
 * "Is the organisation using this add-in currently paying for it?"
 *
 * How it works:
 * 1. The add-in sends the user's ID and tenant (org) ID as query parameters
 * 2. We look up whether that tenant has an Active subscription in Table Storage
 * 3. If yes: we issue a 24-hour JWT token and return { licensed: true, token, plan }
 * 4. If no: we return { licensed: false, reason: "no_subscription" }
 *
 * The add-in caches the JWT for 24 hours so it doesn't call this function
 * on every single startup — just once a day.
 *
 * CORS: Because the add-in runs on github.io and this function runs on
 * azurewebsites.net, the browser would normally block the request.
 * We add CORS headers to tell the browser "it's OK, I trust that origin."
 */

// Import the Azure Functions v4 SDK app object.
// This is how we register our function with the Azure runtime.
const { app } = require("@azure/functions");

// Import our storage helper to look up subscriptions.
const { getActiveSubscriptionForTenant, recordUserAccess } = require("../shared/tableStorage");

// Import our JWT helper to issue license tokens.
const { issueLicenseToken } = require("../shared/jwtHelper");

// Read the allowed origins from environment variables.
// This is a comma-separated list of URLs we trust (our GitHub Pages URLs).
// Example: "https://leighton-grey.github.io,https://grey8ghost.github.io"
// The split and map converts it to an array: ["https://leighton-grey.github.io", ...]
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim());

/**
 * corsHeaders — Builds the CORS response headers for a given request origin.
 *
 * CORS (Cross-Origin Resource Sharing) is a browser security feature.
 * A browser running at github.io is not allowed to call an API at azurewebsites.net
 * UNLESS the API responds with headers explicitly saying "I allow requests from github.io".
 * Without these headers, the browser blocks the response before the add-in ever sees it.
 *
 * @param {string} requestOrigin - The 'origin' header from the incoming request
 * @returns {object}             - HTTP headers to include in the response
 */
function corsHeaders(requestOrigin) {
  // Check if the request's origin is in our allowed list.
  // If yes, echo it back exactly. If no, echo back the first allowed origin.
  // (Browsers check that the response header EXACTLY matches the request origin.)
  const origin = ALLOWED_ORIGINS.includes(requestOrigin) ? requestOrigin : ALLOWED_ORIGINS[0] || "*";

  return {
    // Tell the browser which origin is allowed to read this response.
    "Access-Control-Allow-Origin": origin,
    // Which HTTP methods are allowed from that origin.
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    // Which request headers the browser is allowed to send.
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    // We're always returning JSON.
    "Content-Type": "application/json"
  };
}

// Register the function with the Azure Functions runtime.
// app.http() says "this is an HTTP-triggered function".
app.http("licenseCheck", {
  methods: ["GET", "OPTIONS"], // Only respond to GET and OPTIONS (OPTIONS is for CORS preflight)
  authLevel: "anonymous",      // No Azure Function key required — our own CORS check is the gate
  route: "license",            // The URL path: /api/license
  handler: async (request, context) => {
    // Get the 'origin' header — this tells us where the browser request came from.
    const origin = request.headers.get("origin") || "";

    // Build our CORS headers. We need these on EVERY response, including errors.
    const headers = corsHeaders(origin);

    // CORS preflight: browsers send an OPTIONS request first to ask "can I call this API?"
    // We must respond with 204 (No Content) + CORS headers to say "yes".
    // Without handling OPTIONS, all real GET requests from the browser will fail.
    if (request.method === "OPTIONS") {
      return { status: 204, headers };
    }

    // Read the query parameters from the URL.
    // Example URL: /api/license?userId=abc123&tenantId=xyz789&email=user@company.com
    const userId   = request.query.get("userId");   // The user's Entra object ID
    const tenantId = request.query.get("tenantId"); // The organisation's Entra tenant ID
    const userEmail = request.query.get("email") || ""; // Optional — for the access log

    // If either required parameter is missing, return a 400 Bad Request.
    // We can't do a meaningful license check without knowing who the user is.
    if (!userId || !tenantId) {
      return {
        status: 400,
        headers,
        body: JSON.stringify({ licensed: false, reason: "missing_params" })
      };
    }

    try {
      // THE MAIN CHECK: ask Table Storage if this tenant has an active subscription.
      // This single call determines whether the user is licensed.
      const subscription = await getActiveSubscriptionForTenant(tenantId);

      // No subscription found for this tenant — they haven't bought yet.
      if (!subscription) {
        return {
          status: 200, // Note: we return 200 even for "not licensed" — it's not an error,
          headers,     // it's just the answer to our question. Only real errors get 4xx/5xx.
          body: JSON.stringify({ licensed: false, reason: "no_subscription" })
        };
      }

      // Subscription found, but it's suspended (usually means failed payment).
      if (subscription.status === "Suspended") {
        return {
          status: 200,
          headers,
          body: JSON.stringify({ licensed: false, reason: "suspended", plan: subscription.planId })
        };
      }

      // ✅ Subscription is Active — issue a license token.
      // This JWT is what the add-in caches for 24 hours.
      const token = issueLicenseToken(userId, tenantId, subscription.planId);

      // Calculate the token's expiry time as an ISO date string.
      // Date.now() is current time in milliseconds. Add 24 hours (24 * 60 * 60 * 1000 ms).
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

      // Record this user access in the users table — purely for analytics.
      // We fire it without 'await' so it runs in the background.
      // The .catch() prevents a storage write failure from crashing our response.
      // The user gets their license response whether or not the analytics write succeeds.
      recordUserAccess(tenantId, userId, userEmail).catch(err =>
        context.log("recordUserAccess failed (non-fatal):", err.message)
      );

      // Return the success response. The add-in receives this and caches the token.
      return {
        status: 200,
        headers,
        body: JSON.stringify({
          licensed: true,              // The key field — the add-in checks this first
          plan: subscription.planId,   // e.g. "pro" — useful for showing plan info in the UI
          token,                       // The JWT — cached by the add-in for 24 hours
          expiresAt                    // ISO timestamp — so the add-in knows when to refresh
        })
      };
    } catch (err) {
      // Something went wrong on our end (storage error, etc.).
      // Log it for debugging — visible in Azure Portal → Function App → Log stream.
      context.log.error("licenseCheck error:", err);

      // Return 500 Internal Server Error. The add-in treats server errors as "fail open"
      // — it won't block the user just because our server had a bad moment.
      return {
        status: 500,
        headers,
        body: JSON.stringify({ licensed: false, reason: "server_error" })
      };
    }
  }
});
