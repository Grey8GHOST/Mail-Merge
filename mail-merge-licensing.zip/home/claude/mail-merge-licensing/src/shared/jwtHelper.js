/**
 * jwtHelper.js — The ID Card Printer
 *
 * JWT stands for JSON Web Token. Think of it like a signed, tamper-proof ID card.
 * When a user is confirmed as licensed, we print them a 24-hour card.
 * The add-in caches this card and shows it instead of calling the server
 * on every single startup. Faster for the user, cheaper for us.
 *
 * A JWT has three parts separated by dots:
 *   header.payload.signature
 *
 * - Header: says what algorithm was used to sign it (we use HS256)
 * - Payload: the data we stored (userId, tenantId, plan, expiry)
 * - Signature: a cryptographic stamp using our SECRET key
 *
 * If anyone tampers with the payload (e.g. changes 'licensed: false' to 'true'),
 * the signature no longer matches and the verify() call throws an error.
 * That's the whole point — you can READ a JWT without the secret, but you
 * cannot CREATE or MODIFY one without it.
 */

// Load the jsonwebtoken library — this is what does the heavy cryptography for us.
// We installed it via: npm install jsonwebtoken
const jwt = require("jsonwebtoken");

// Read the signing secret from environment variables.
// NEVER hardcode this — it must be a long random string stored in Azure Function
// App settings (or .env locally). Anyone with this secret can forge license tokens.
// Generate one with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
const SECRET = process.env.LICENSE_JWT_SECRET;

// How long each token is valid for. "24h" is a string the jwt library understands.
// After 24 hours the token expires and the add-in must call licenseCheck again to renew.
// This balances freshness (cancelled subscriptions are blocked within a day)
// vs. performance (the server isn't called on every add-in startup).
const EXPIRY = "24h";

/**
 * issueLicenseToken — Prints a new ID card for a licensed user.
 *
 * @param {string} userId   - The user's Entra object ID (e.g. "a1b2c3d4-...")
 * @param {string} tenantId - The user's organisation's tenant ID
 * @param {string} planId   - The subscription plan (e.g. "pro", "enterprise")
 * @returns {string}        - A JWT string, e.g. "eyJhbGc..."
 */
function issueLicenseToken(userId, tenantId, planId) {
  return jwt.sign(
    // First argument: the payload — the data baked into the card.
    // 'sub' is a standard JWT claim meaning "subject" (who this token is for).
    // 'tid' is our custom claim for tenantId.
    // 'plan' is our custom claim for the subscription tier.
    // 'licensed: true' is the key flag the add-in can check quickly.
    { sub: userId, tid: tenantId, plan: planId, licensed: true },

    // Second argument: the secret key used to sign the token.
    // This is what makes the signature valid. Keep it safe.
    SECRET,

    // Third argument: options.
    // expiresIn adds an 'exp' claim to the payload automatically.
    // issuer adds an 'iss' claim — we check this on verify to confirm
    // the token came from OUR system, not some other service.
    { expiresIn: EXPIRY, issuer: "mail-merge-licensing" }
  );
  // jwt.sign() returns a string like: "eyJhbGciOiJIUzI1NiJ9.eyJzdWIi..."
  // This string is safe to store in localStorage on the client.
}

/**
 * verifyLicenseToken — Checks if an ID card is genuine and still valid.
 *
 * @param {string} token - The JWT string from the client's localStorage cache
 * @returns {object|null} - The decoded payload if valid, or null if expired/tampered
 */
function verifyLicenseToken(token) {
  try {
    // jwt.verify() does three things in one call:
    // 1. Checks the signature is valid (using SECRET)
    // 2. Checks the token hasn't expired (the 'exp' claim)
    // 3. Checks the issuer matches what we expect
    // If all three pass, it returns the decoded payload object.
    // If any fail, it throws an error — caught below.
    return jwt.verify(token, SECRET, { issuer: "mail-merge-licensing" });
  } catch {
    // Any failure — expired, tampered, wrong issuer, malformed — returns null.
    // The caller treats null as "not licensed, check again with the API".
    // We don't distinguish between expired vs tampered here because the
    // response is the same either way: go re-validate.
    return null;
  }
}

// Export both functions so other files can use them.
// Only these two functions are exposed — the SECRET stays private inside this module.
module.exports = { issueLicenseToken, verifyLicenseToken };
