/**
 * tableStorage.js — The Filing Cabinet
 *
 * This is the ONLY file in the entire project that talks to Azure Table Storage.
 * Every other file calls these helper functions instead of talking to Azure directly.
 *
 * Why centralise it like this?
 * If we ever want to switch from Table Storage to a real database (e.g. PostgreSQL),
 * we only have to change THIS file. Nothing else needs to know what database we use.
 * This pattern is called "separation of concerns" — each file has one job.
 *
 * Azure Table Storage is like a giant spreadsheet in the cloud.
 * Rows are called "entities". Every entity must have two special fields:
 *   - partitionKey: groups related rows together (we use tenantId)
 *   - rowKey:       uniquely identifies a row within a partition (we use subscriptionId)
 *
 * We have two tables:
 *   "subscriptions" — one row per organisation's subscription
 *   "users"         — one row per user who has accessed the add-in (for analytics)
 */

// Import only what we need from the Azure SDK.
// TableClient  — lets us talk to a specific table (read, write, query rows)
// odata        — a template tag function for building safe filter strings (like parameterised SQL)
const { TableClient, odata } = require("@azure/data-tables");

// Read the connection string from an environment variable.
// The connection string contains the storage account name, key, and URL.
// It lives in Azure Function App settings (or local.settings.json locally).
// NEVER hardcode this — it gives full read/write access to your storage account.
const CONNECTION_STRING = process.env.AZURE_STORAGE_CONNECTION_STRING;

// Constants for table names — using constants prevents typos scattered through the code.
// If you rename a table, you change it here and nowhere else breaks.
const SUBSCRIPTIONS_TABLE = "subscriptions";
const USERS_TABLE = "users";

// A Map to cache TableClient instances by table name.
// Without this cache, every storage call would create a brand new client object —
// wasting memory and time. With the cache, each table gets one client for the
// lifetime of the Azure Function process (which can serve thousands of requests).
const _clients = new Map();

/**
 * getTableClient — Returns a ready-to-use client for a specific table.
 * Creates the table automatically if it doesn't exist yet.
 * Caches the client so it's only created once per table name.
 *
 * @param {string} tableName - The name of the table (e.g. "subscriptions")
 * @returns {TableClient}    - An Azure SDK client for that table
 */
async function getTableClient(tableName) {
  // Check the cache first. If we've already set up this table's client, return it immediately.
  // Map.has() is O(1) — instant lookup regardless of how many tables are cached.
  if (_clients.has(tableName)) return _clients.get(tableName);

  // No cached client yet — create one using the connection string.
  // TableClient.fromConnectionString() parses the connection string and
  // creates an authenticated client ready to make API calls.
  const client = TableClient.fromConnectionString(CONNECTION_STRING, tableName);

  try {
    // Try to create the table. On first deployment this is needed.
    // On subsequent calls the table already exists, which causes a 409 error (see below).
    // This means we never need to manually create tables in the Azure Portal —
    // they appear automatically the first time the function runs.
    await client.createTable();
  } catch (e) {
    // Error code 409 = "Conflict" = the table already exists.
    // That's totally fine — we just wanted to make sure it existed.
    // Any other error code is a real problem (wrong credentials, network failure, etc.)
    // so we re-throw it to let the caller handle it.
    if (e.statusCode !== 409) throw e;
  }

  // Store the client in the cache before returning.
  // Next call for this table name hits the 'if (_clients.has(...))' above and
  // skips all this setup work entirely.
  _clients.set(tableName, client);
  return client;
}

// ────────────────────────────────────────────────────────────────────────────
// SUBSCRIPTIONS
// ────────────────────────────────────────────────────────────────────────────

/**
 * upsertSubscription — Saves or updates a subscription record.
 *
 * "Upsert" = Insert if the row doesn't exist, Update if it does.
 * This is safer than separate insert/update logic because:
 * - The AppSource activation page and the Subscribed webhook event can BOTH
 *   try to write the same subscription. Upsert handles both gracefully.
 * - If a plan changes, we call upsert again — it merges the new fields in.
 *
 * @param {object} sub - Subscription data object (see field list in JSDoc above file)
 */
async function upsertSubscription(sub) {
  // Get (or create) the client for the subscriptions table.
  const client = await getTableClient(SUBSCRIPTIONS_TABLE);

  // Build the entity object. Azure Table Storage requires partitionKey and rowKey.
  // The spread operator (...sub) copies all the fields from the sub argument into entity.
  // We then add/override partitionKey, rowKey, and updatedAt.
  const entity = {
    partitionKey: sub.tenantId,      // Groups all subscriptions by organisation
    rowKey: sub.subscriptionId,      // Unique ID within that organisation's rows
    ...sub,                          // Copies all other fields (planId, status, email, etc.)
    updatedAt: new Date().toISOString() // Always stamp when this record was last touched
  };

  // "Merge" mode means: if the row exists, merge new fields in (don't wipe old ones).
  // Alternative: "Replace" would delete all old fields first. We want Merge.
  await client.upsertEntity(entity, "Merge");
}

/**
 * getActiveSubscriptionForTenant — Checks if an organisation has an active subscription.
 * This is called by licenseCheck.js on every license verification request.
 *
 * @param {string} tenantId - The organisation's Entra tenant ID
 * @returns {object|null}   - The subscription entity, or null if none found
 */
async function getActiveSubscriptionForTenant(tenantId) {
  const client = await getTableClient(SUBSCRIPTIONS_TABLE);

  // Build a filter query. The odata template tag is critical here —
  // it safely escapes the tenantId value before inserting it into the filter string.
  // Without odata``, if tenantId contained a single quote character,
  // the filter string would break or behave unexpectedly (like SQL injection).
  // ALWAYS use odata`` for dynamic values. Never use string concatenation.
  const entities = client.listEntities({
    queryOptions: { filter: odata`PartitionKey eq ${tenantId} and status eq 'Active'` }
  });

  // listEntities() returns an async iterator — it streams results from Azure
  // one page at a time rather than loading all rows into memory at once.
  // 'for await ... of' reads from an async iterator.
  for await (const entity of entities) {
    // Return the FIRST Active subscription we find for this tenant.
    // Most organisations will have exactly one. The loop exits immediately.
    return entity;
  }

  // If we looped through all results and found nothing, return null.
  // licenseCheck.js treats null as "not licensed".
  return null;
}

/**
 * getSubscription — Finds one specific subscription by both tenantId and subscriptionId.
 * This is a FAST point lookup — O(1) because we know both the partition and row keys.
 *
 * @param {string} tenantId       - The organisation's tenant ID (the partition key)
 * @param {string} subscriptionId - The Microsoft-assigned subscription ID (the row key)
 * @returns {object|null}         - The entity, or null if not found
 */
async function getSubscription(tenantId, subscriptionId) {
  const client = await getTableClient(SUBSCRIPTIONS_TABLE);
  try {
    // getEntity() retrieves a single row by its exact partition + row key.
    // This is the fastest possible query — Azure can find it in one indexed lookup.
    return await client.getEntity(tenantId, subscriptionId);
  } catch (e) {
    // 404 means "not found" — a normal case, not an error to crash on.
    if (e.statusCode === 404) return null;
    // Any other error (network failure, auth problem) is re-thrown.
    throw e;
  }
}

/**
 * getSubscriptionById — Finds a subscription by subscriptionId alone, WITHOUT the tenantId.
 *
 * WHY THIS EXISTS (the bug fix):
 * Microsoft's webhook events for cancel/suspend/reinstate only provide the subscriptionId,
 * not the tenantId. Our table is organised by tenantId (as the partitionKey), so we
 * can't do a fast point lookup without it. This function does a slower scan by RowKey.
 *
 * NOTE: This is a cross-partition scan (full table scan). Azure reads ALL partitions
 * looking for matching RowKeys. At typical SaaS volumes (thousands of subscriptions)
 * this runs in under 100ms and costs fractions of a cent. If you ever reach 100k+
 * subscriptions, add a secondary index table (subscriptionId → tenantId) for O(1) lookup.
 *
 * @param {string} subscriptionId - The Microsoft-assigned subscription ID
 * @returns {object|null}         - The entity, or null if not found
 */
async function getSubscriptionById(subscriptionId) {
  const client = await getTableClient(SUBSCRIPTIONS_TABLE);

  // Filter by RowKey alone. odata`` safely escapes the subscriptionId.
  // This scans all partitions (all tenants) looking for a matching RowKey.
  const entities = client.listEntities({
    queryOptions: { filter: odata`RowKey eq ${subscriptionId}` }
  });

  // Return the first match. SubscriptionIds from Microsoft are globally unique UUIDs,
  // so there should only ever be one match.
  for await (const entity of entities) {
    return entity;
  }
  return null;
}

/**
 * updateSubscriptionStatus — Changes the status field of an existing subscription.
 * Used by the webhook when subscriptions are cancelled, suspended, or reinstated.
 *
 * @param {string} tenantId       - The organisation's tenant ID
 * @param {string} subscriptionId - The subscription's ID
 * @param {string} status         - New status: 'Active', 'Suspended', or 'Unsubscribed'
 */
async function updateSubscriptionStatus(tenantId, subscriptionId, status) {
  const client = await getTableClient(SUBSCRIPTIONS_TABLE);

  // updateEntity() with "Merge" mode ONLY updates the fields we provide.
  // We only touch 'status' and 'updatedAt' — all other fields (planId, email, etc.) stay intact.
  // Using "Replace" instead would wipe everything else — dangerous.
  await client.updateEntity({
    partitionKey: tenantId,             // Identifies which partition (which organisation)
    rowKey: subscriptionId,             // Identifies which row within that partition
    status,                             // The new status value (e.g. "Suspended")
    updatedAt: new Date().toISOString() // Timestamp so we know when this change happened
  }, "Merge");
}

// ────────────────────────────────────────────────────────────────────────────
// USER ACCESS LOG
// ────────────────────────────────────────────────────────────────────────────

/**
 * recordUserAccess — Logs that a specific user accessed the add-in.
 *
 * This builds an audit trail: which users in which organisations used the product.
 * Useful for:
 * - Analytics (how many users per org?)
 * - Future per-seat pricing (charge based on unique active users)
 * - Support (when did a specific user last use the add-in?)
 *
 * @param {string} tenantId - The user's organisation's tenant ID
 * @param {string} userId   - The user's Entra object ID (unique per user)
 * @param {string} email    - The user's email address (human-readable identifier)
 */
async function recordUserAccess(tenantId, userId, email) {
  const client = await getTableClient(USERS_TABLE);

  // Upsert: if the user has accessed before, update their lastSeen timestamp.
  // If they're new, create a fresh row for them.
  // We use Merge mode so we never accidentally wipe any extra fields
  // that might be added to this record in the future.
  await client.upsertEntity({
    partitionKey: tenantId,              // Group users by their organisation
    rowKey: userId,                      // Unique per user within that organisation
    email,                               // Human-readable — useful in Azure Portal
    lastSeen: new Date().toISOString()   // Timestamp of this access
  }, "Merge");
}

// Export all the functions that other files need.
// The _clients Map and getTableClient are NOT exported — they're internal implementation
// details. Other files don't need to know HOW we manage clients, just WHAT we can do.
module.exports = {
  upsertSubscription,
  getActiveSubscriptionForTenant,
  getSubscription,
  getSubscriptionById,
  updateSubscriptionStatus,
  recordUserAccess
};
