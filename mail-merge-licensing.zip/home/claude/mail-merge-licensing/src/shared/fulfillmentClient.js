/**
 * fulfillmentClient.js — The Phone to Microsoft's Billing Office
 *
 * Microsoft has a SaaS Fulfillment API that we must call for two things:
 *   1. ACTIVATION: When a new customer lands on our activation page, we call this
 *      API to confirm the purchase was real and to officially activate the subscription.
 *   2. ACKNOWLEDGEMENT: After receiving a webhook event (cancel, suspend, etc.), we
 *      must call this API to confirm we received and processed it.
 *
 * This file handles ALL communication with that Microsoft API.
 * It gets an access token automatically, caches it so we don't re-authenticate on
 * every call, and provides clean functions for each API operation.
 *
 * Microsoft SaaS Fulfillment API docs:
 * https://learn.microsoft.com/en-us/azure/marketplace/partner-center-portal/pc-saas-fulfillment-subscription-api
 *
 * Required environment variables (set in Azure Function App settings):
 *   MARKETPLACE_CLIENT_ID     — Your Entra app registration's client ID
 *   MARKETPLACE_CLIENT_SECRET — Your Entra app registration's client secret
 *   MARKETPLACE_TENANT_ID     — Your publisher (Promethean IT) tenant ID
 */

// The base URL for Microsoft's Marketplace Fulfillment API.
// All our API calls start with this URL.
const FULFILLMENT_API = "https://marketplaceapi.microsoft.com/api/saas";

// The API version to use. Microsoft uses versioned APIs so old code keeps working
// even when they release new features. Always pin to a specific version.
const API_VERSION = "2018-08-31";

// The URL to get an OAuth access token from. Uses our publisher tenant ID.
// This is the same authentication system as signing into Microsoft 365.
const TOKEN_URL = `https://login.microsoftonline.com/${process.env.MARKETPLACE_TENANT_ID}/oauth2/token`;

// Token cache — store the current token and when it expires.
// Without this, we'd make a new authentication call before EVERY API call.
// With it, we reuse the same token for its entire ~1 hour lifetime.
let _cachedToken = null;  // The token string itself (starts with "eyJ...")
let _tokenExpiry = 0;     // Unix timestamp (milliseconds) when this token expires

/**
 * getAccessToken — Gets a valid OAuth access token, using the cache if possible.
 *
 * This uses the "client credentials" OAuth flow — no user is involved.
 * Our server authenticates AS ITSELF (using client ID + secret) to get a token
 * that proves to Microsoft's API that we are the publisher of this SaaS offer.
 *
 * @returns {string} - A Bearer token string to put in API request headers
 */
async function getAccessToken() {
  // Check if we have a cached token that won't expire in the next 60 seconds.
  // The 60-second buffer prevents edge cases where the token expires mid-request.
  if (_cachedToken && Date.now() < _tokenExpiry - 60000) {
    return _cachedToken; // Cache hit — return immediately, no network call needed
  }

  // Build the form body for the token request.
  // URLSearchParams encodes this as "grant_type=client_credentials&client_id=..."
  // which is the format the token endpoint expects (application/x-www-form-urlencoded).
  const params = new URLSearchParams({
    grant_type: "client_credentials",            // We're authenticating as our app, not a user
    client_id: process.env.MARKETPLACE_CLIENT_ID,        // Our Entra app's ID
    client_secret: process.env.MARKETPLACE_CLIENT_SECRET, // Our Entra app's secret (like a password)
    resource: "20e940b3-4c77-4b0b-9a53-9e16a1b010a7"     // The resource ID for the Marketplace API
    // This GUID is Microsoft's fixed ID for their Marketplace API — it never changes
  });

  // Make the authentication request to Microsoft's OAuth endpoint.
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString() // Converts URLSearchParams to a query string like "a=1&b=2"
  });

  // If the authentication failed (wrong credentials, etc.), throw an error with details.
  if (!res.ok) {
    const text = await res.text(); // Read the error message from Microsoft
    throw new Error(`Token fetch failed: ${res.status} ${text}`);
  }

  // Parse the JSON response. It contains: access_token, expires_in (seconds), token_type
  const data = await res.json();

  // Cache the token and calculate its expiry time.
  _cachedToken = data.access_token;
  // expires_in is in seconds — multiply by 1000 to convert to milliseconds for Date.now()
  _tokenExpiry = Date.now() + (data.expires_in * 1000);

  return _cachedToken;
}

/**
 * apiCall — Makes an authenticated request to the Fulfillment API.
 *
 * This is a private helper used by all the public functions below.
 * It handles: getting a token, building the URL with the API version, setting headers,
 * optionally sending a JSON body, and parsing the response.
 *
 * @param {string} method - HTTP method: "GET", "POST", "PATCH"
 * @param {string} path   - The API path, e.g. "/subscriptions/abc123/activate"
 * @param {object} body   - Optional request body (for POST/PATCH calls)
 * @returns {object|null} - Parsed JSON response, or null for empty responses
 */
async function apiCall(method, path, body = null) {
  // Get a valid token (from cache or fresh from Microsoft)
  const token = await getAccessToken();

  // Build the full URL: base + path + API version query parameter
  const url = `${FULFILLMENT_API}${path}?api-version=${API_VERSION}`;

  // Build the request options object
  const opts = {
    method, // "GET", "POST", or "PATCH"
    headers: {
      Authorization: `Bearer ${token}`, // The token proves we're authenticated
      "Content-Type": "application/json" // Tell Microsoft we're sending JSON
    }
  };

  // Only add a request body for POST and PATCH calls (GET has no body)
  if (body) opts.body = JSON.stringify(body); // Convert the JS object to a JSON string

  // Make the actual API call
  const res = await fetch(url, opts);

  // If Microsoft returns an error status (4xx or 5xx), throw with details
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Fulfillment API ${method} ${path} failed: ${res.status} ${text}`);
  }

  // Some responses have no body (e.g. acknowledge returns 200 with no content).
  // Check if there's anything to parse before calling JSON.parse.
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

// ────────────────────────────────────────────────────────────────────────────
// PUBLIC API FUNCTIONS
// ────────────────────────────────────────────────────────────────────────────

/**
 * resolveSubscription — Exchanges a marketplace token for full subscription details.
 *
 * When a customer buys on AppSource, Microsoft redirects them to our activation page
 * with a short-lived token (valid for ~10 minutes). We must exchange this token for
 * the actual subscription object BEFORE we can activate it.
 *
 * The resolved object contains: subscriptionId, planId, tenantId, purchaser email,
 * beneficiary email, offerId, publisherId, quantity, and more.
 *
 * @param {string} marketplaceToken - The token from the URL query string (?token=...)
 * @returns {object}                - The resolved subscription details from Microsoft
 */
async function resolveSubscription(marketplaceToken) {
  // POST to the resolve endpoint with the token in the body.
  // Microsoft looks up the token, validates it's not expired, and returns the subscription.
  return apiCall("POST", "/subscriptions/resolve", { marketplaceToken });
}

/**
 * activateSubscription — Officially activates a subscription after the customer confirms.
 *
 * After resolveSubscription() gives us the details and we've stored them, we MUST call
 * this to tell Microsoft "yes, we've accepted this sale". Without this call, Microsoft
 * keeps the subscription in "PendingFulfillmentStart" state and may cancel it after a few days.
 *
 * @param {string} subscriptionId - The subscription's ID from resolveSubscription()
 * @param {string} planId         - The plan the customer bought (e.g. "pro")
 * @param {number} quantity       - Number of seats (default 1 for per-org plans)
 * @returns {null}                - This call returns no body on success
 */
async function activateSubscription(subscriptionId, planId, quantity = 1) {
  // PATCH the subscription's activate sub-resource.
  // We confirm the planId and quantity we're activating them for.
  return apiCall("POST", `/subscriptions/${subscriptionId}/activate`, {
    planId,   // Confirm which plan they're on
    quantity  // Confirm how many seats
  });
}

/**
 * getSubscription — Fetches the current details of a subscription from Microsoft.
 *
 * Used in the webhook handler when we need the full subscription object
 * (including tenantId) that isn't included in all webhook payloads.
 *
 * @param {string} subscriptionId - The subscription to look up
 * @returns {object}              - Full subscription details from Microsoft
 */
async function getSubscription(subscriptionId) {
  // Simple GET — no body needed
  return apiCall("GET", `/subscriptions/${subscriptionId}`);
}

/**
 * acknowledgeOperation — Tells Microsoft we processed a webhook event.
 *
 * After receiving and handling a webhook event (cancel, suspend, etc.), we MUST
 * call this within a reasonable time to confirm we processed it.
 * If we don't acknowledge, Microsoft considers the operation failed and may retry.
 *
 * @param {string} subscriptionId - The subscription the operation belongs to
 * @param {string} operationId    - The specific operation ID from the webhook payload
 * @param {string} status         - "Success" if we handled it, "Failure" if we couldn't
 * @returns {null}                - No response body
 */
async function acknowledgeOperation(subscriptionId, operationId, status = "Success") {
  // PATCH the operation to mark it as acknowledged.
  return apiCall("PATCH", `/subscriptions/${subscriptionId}/operations/${operationId}`, {
    status,    // "Success" or "Failure"
    quantity: 1 // Required field even though we're just acknowledging
  });
}

// Export only the public-facing functions.
// getAccessToken() and apiCall() are internal helpers — not exported.
// Other files only need to know WHAT they can do (resolve, activate, etc.),
// not HOW authentication or HTTP requests work internally.
module.exports = {
  resolveSubscription,
  activateSubscription,
  getSubscription,
  acknowledgeOperation
};
